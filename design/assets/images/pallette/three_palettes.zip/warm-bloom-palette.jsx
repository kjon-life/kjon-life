export default function WarmBloomPalette() {
  const colors = [
    { hex: '#f1c5d5', name: 'Blushed Pink', usage: 'soft highlight' },
    { hex: '#f77f85', name: 'Ember', usage: 'CTA/alert' },
    { hex: '#ffb347', name: 'Mandarin Glow', usage: 'vibrant accent' },
    { hex: '#f9d976', name: 'Goldlight', usage: 'background for cards' },
    { hex: '#8ed1c0', name: 'Minted Sea', usage: 'secondary accent' },
    { hex: '#3fa7a5', name: 'Deep Teal', usage: 'strong contrast accent' },
    { hex: '#615c8b', name: 'Dusk Violet', usage: 'anchor' },
    { hex: '#1f1f2b', name: 'Midnight Slate', usage: 'bold foundation' },
  ];

  const getTextColor = (hex) => {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    return luminance > 0.5 ? '#1f1f2b' : '#ffffff';
  };

  return (
    <div className="min-h-screen p-8" style={{ backgroundColor: '#1f1f2b' }}>
      <h1 className="text-3xl font-bold mb-2 text-white">Warm Bloom</h1>
      <p className="text-gray-400 mb-8">Sunrise-inspired balance</p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {colors.map((color) => (
          <div
            key={color.hex}
            className="rounded-lg overflow-hidden shadow-lg"
            style={{ backgroundColor: color.hex }}
          >
            <div className="h-24" />
            <div 
              className="p-4"
              style={{ color: getTextColor(color.hex) }}
            >
              <p className="font-semibold text-lg">{color.name}</p>
              <p className="font-mono text-sm opacity-80">{color.hex}</p>
              <p className="text-sm mt-1 opacity-70">{color.usage}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8">
        <h2 className="text-xl font-semibold mb-4 text-white">Full Spectrum</h2>
        <div className="flex rounded-lg overflow-hidden shadow-lg h-16">
          {colors.map((color) => (
            <div
              key={color.hex}
              className="flex-1 transition-all hover:flex-grow-[2] cursor-pointer"
              style={{ backgroundColor: color.hex }}
              title={`${color.name} - ${color.hex}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
