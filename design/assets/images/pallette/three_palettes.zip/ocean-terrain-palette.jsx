export default function OceanTerrainPalette() {
  const colors = [
    { hex: '#e3f6ff', name: 'Cloud Surf', usage: 'airy background' },
    { hex: '#8dd7ff', name: 'Lagoon Tint', usage: 'soft highlight' },
    { hex: '#54b7ec', name: 'Tide', usage: 'primary action' },
    { hex: '#1c6a89', name: 'Deep Bay', usage: 'strong accent' },
    { hex: '#f4a261', name: 'Lava Sand', usage: 'warm counterpart' },
    { hex: '#f07c52', name: 'Coral Spark', usage: 'attention' },
    { hex: '#a06cde', name: 'Royal Reef', usage: 'rich accent' },
    { hex: '#09121b', name: 'Abyssal', usage: 'dark base' },
  ];

  const getTextColor = (hex) => {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    return luminance > 0.5 ? '#09121b' : '#e3f6ff';
  };

  return (
    <div className="min-h-screen p-8" style={{ backgroundColor: '#09121b' }}>
      <h1 className="text-3xl font-bold mb-2" style={{ color: '#e3f6ff' }}>Ocean Terrain</h1>
      <p className="mb-8" style={{ color: '#54b7ec' }}>Vivid depth</p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {colors.map((color) => (
          <div
            key={color.hex}
            className="rounded-lg overflow-hidden shadow-lg"
            style={{ backgroundColor: color.hex }}
          >
            <div className="h-24" />
            <div 
              className="p-4"
              style={{ color: getTextColor(color.hex) }}
            >
              <p className="font-semibold text-lg">{color.name}</p>
              <p className="font-mono text-sm opacity-80">{color.hex}</p>
              <p className="text-sm mt-1 opacity-70">{color.usage}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8">
        <h2 className="text-xl font-semibold mb-4" style={{ color: '#e3f6ff' }}>Full Spectrum</h2>
        <div className="flex rounded-lg overflow-hidden shadow-lg h-16">
          {colors.map((color) => (
            <div
              key={color.hex}
              className="flex-1 transition-all hover:flex-grow-[2] cursor-pointer"
              style={{ backgroundColor: color.hex }}
              title={`${color.name} - ${color.hex}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
