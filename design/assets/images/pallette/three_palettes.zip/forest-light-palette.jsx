export default function ForestLightPalette() {
  const colors = [
    { hex: '#fdf2d5', name: 'Soft Sand', usage: 'main background' },
    { hex: '#f4c95d', name: 'Meadow Sun', usage: 'primary highlight' },
    { hex: '#e07a5f', name: 'Clay Bloom', usage: 'energetic accent' },
    { hex: '#d66c93', name: 'Hibiscus', usage: 'secondary accent' },
    { hex: '#6ea88b', name: 'Fern Mist', usage: 'calming mid tone' },
    { hex: '#3c9d9b', name: 'Riverstone', usage: 'deeper contrast' },
    { hex: '#4b3f72', name: 'Thistle Shadow', usage: 'anchor' },
    { hex: '#14141f', name: 'Deep Forest', usage: 'dark base' },
  ];

  const getTextColor = (hex) => {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    return luminance > 0.5 ? '#14141f' : '#fdf2d5';
  };

  return (
    <div className="min-h-screen p-8" style={{ backgroundColor: '#14141f' }}>
      <h1 className="text-3xl font-bold mb-2" style={{ color: '#fdf2d5' }}>Forest Light</h1>
      <p className="mb-8" style={{ color: '#6ea88b' }}>Living nature</p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {colors.map((color) => (
          <div
            key={color.hex}
            className="rounded-lg overflow-hidden shadow-lg"
            style={{ backgroundColor: color.hex }}
          >
            <div className="h-24" />
            <div 
              className="p-4"
              style={{ color: getTextColor(color.hex) }}
            >
              <p className="font-semibold text-lg">{color.name}</p>
              <p className="font-mono text-sm opacity-80">{color.hex}</p>
              <p className="text-sm mt-1 opacity-70">{color.usage}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8">
        <h2 className="text-xl font-semibold mb-4" style={{ color: '#fdf2d5' }}>Full Spectrum</h2>
        <div className="flex rounded-lg overflow-hidden shadow-lg h-16">
          {colors.map((color) => (
            <div
              key={color.hex}
              className="flex-1 transition-all hover:flex-grow-[2] cursor-pointer"
              style={{ backgroundColor: color.hex }}
              title={`${color.name} - ${color.hex}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
